import random

print("WELCOME TO A GAME OF GUESS THE NUMBER FROM 1 TO 20")
print("You will get 3 chances to guess the number from 1 to 20")

num = random.randint(1, 20)  
wrng = 0
chnc = 3

for i in range(chnc):
    gsnum = int(input("Enter the number you've guessed: "))
    
    if gsnum > num:
        print("Bad luck, TRY A SMALLER NUMBER")  
        wrng += 1
    elif gsnum < num:
        print("Bad luck, TRY A LARGER NUMBER")
        wrng += 1
    else:
        print("GUESS WHAT, YOU WON!")
        break

if wrng == chnc:
    print("NOOB, you couldn't guess the correct answer. The real answer was:", num)
